/*Creazione DB e TabelleDB*/

CREATE DATABASE TOYSGROUP;

USE TOYSGROUP

/*� stato pecificato se gli attributi possono contenere o meno dei valori NULL. Ovviamente le PK saranno sempre NOT NULL di regola. 
In campo price ho specificato NULL perch� si potrebbe non sapere ancora il prezzo da assegnare ad un prodotto, il valore potrebbe 
quindi essere inesistente. Per il campo data non � stato invece specificato perch� sar� comunque completato automaticamente. 
In SalesID della tabella Sales � stato specificato NULL perch� potrei non sapere dove � stato venduto il prodotto. 
Sono poi state inserite anche le chiavi primarie e secondarie.*/

CREATE TABLE Product(
ProductID INT NOT NULL,
ParentCategoryID INT NULL,
NameProduct VARCHAR(50) NOT NULL,
Price MONEY NULL, 
CONSTRAINT PK_Product PRIMARY KEY (ProductID),
CONSTRAINT FK_Product_Product FOREIGN KEY (ParentCategoryID)
	REFERENCES Product (ProductID));

CREATE TABLE Region(
RegionID INT NOT NULL,
NameR VARCHAR (50) NOT NULL,
CONSTRAINT PK_Region PRIMARY KEY (RegionID));


CREATE TABLE [State](
StateID INT NOT NULL,
NameS VARCHAR(50) NOT NULL,
RegionID INT NOT NULL,
CONSTRAINT PK_State PRIMARY KEY (StateID),
CONSTRAINT FK_State_Region FOREIGN KEY (RegionID)
	REFERENCES Region (RegionID));

CREATE TABLE Sales (
OrderID INT NOT NULL,
ProductID INT NOT NULL,
StateID INT NULL,
OrderDate DATE,
SalesAmount MONEY,
CONSTRAINT PK_Sales PRIMARY KEY (OrderID),
CONSTRAINT FK_Sales_Product FOREIGN KEY (ProductID)
	REFERENCES Product(ProductID),
CONSTRAINT FK_Sales_State FOREIGN KEY (StateID)
	REFERENCES [State] (StateID));

/*Inseriti i valori nelle proprie tabelle.*/

INSERT INTO Product (ProductID,ParentCategoryID,NameProduct,Price)
VALUES 
	(1, NULL, 'Cars', 0), 
	(2, NULL, 'Dolls', 0), 
	(3, NULL, 'Electronic', 0),
	(4, NULL, 'Animals', 0), 
	(5, 1, 'Aoski Camion', 25), 
	(6, 1, 'Hot Wheels', 34),
	(7, 2, 'Barbie', 40),
	(8, 2, 'Bratz', 36), 
	(9, 3, 'Nintendo', 350), 
	(10, 3, 'Xbox', 550),
	(11, 3, 'PlayStation', 600);


INSERT INTO Region (RegionID,NameR)
VALUES 
	(1, 'EUROPE'),
	(2, 'USA');

	
INSERT INTO [State] (StateID,NameS,RegionID)
VALUES
	(10, 'Rome', 1), 
	(11, 'London', 1),
	(12, 'Monaco', 1),
	(13, 'Paris', 1), 
	(14, 'LosAgeles', 2), 
	(15, 'NewYork', 2),
	(16, 'Miami', 2),
	(17, 'SanFrancisco', 2);

INSERT INTO Sales (OrderID, ProductID, StateID, OrderDate, SalesAmount)
VALUES 
	(2556, 8, 11, '2023-05-26', 36),
	(2540, 6, 16, '2023-05-26', 34),	
	(2470, 9, 11, '2023-05-26', 350), 
	(2471, 10, 15, '2023-05-26', 550), 
	(2687, 8, 15, '2023-06-26', 36), 
	(2688, 10, 15, '2023-06-26', 550), 
	(2714, 9, 13, '2023-06-26', 350), 
	(2741, 5, 13, '2023-06-26', 25), 
	(2524, 8, 16, '2023-07-26', 36), 
	(2682, 6, 11, '2023-07-26', 34), 
	(2554, 7, 11, '2023-07-26', 40), 
	(2572, 10, 12, '2023-07-26', 550);

/*task 4: Verificare che i campi definiti come PK siano univoci. In altre parole, 
scrivi una query per determinare l�univocit� dei valori di ciascuna PK (una query per tabella implementata).*/

SELECT COUNT (ProductID)
FROM Product
GROUP BY ProductID

/*per verificare l'univocit�, ogni record deve risultare =1. Oppure:*/

SELECT ProductID
FROM Product
GROUP BY ProductID
HAVING COUNT (*) >1

SELECT RegionID
FROM Region
GROUP BY RegionID
HAVING COUNT (*)>1

SELECT StateID
FROM SalesState
GROUP BY StateID
HAVING COUNT (*)>1

SELECT OrderID
FROM Sales
GROUP BY OrderID
HAVING COUNT (*)>1

/* per verificare l'univocit�, l'interrogazione non restituisce nulla */

/* INIZIO INTERROGAZIONI RICHIESTE: Creazione view (Richiesta 7 e 8) come primo passaggio in modo da unire gi� i record 
che ci interessano tra Stato e Regione ed avere gi� la SelfJoin della tabella Product per avere, dunque, 
i prodotti ordinati per la rispettiva categoria*/

CREATE VIEW VW_SM_StateRegion AS (
SELECT 
	S.StateID, 
	S.NameS, 
	R.NameR
FROM [State] AS S
LEFT JOIN Region AS R
ON S.RegionID = R.RegionID
)  

CREATE VIEW VW_SM_SelfProduct AS (
SELECT 
	p1.ProductID, 
	p1.NameProduct AS Product, 
	p2.NameProduct AS Category
FROM Product AS p1
INNER JOIN Product AS p2
ON p1.ParentCategoryID = p2.ProductID
) 

/* 1. Esporre l�elenco delle transazioni indicando nel result set il codice documento,
la data, il nome del prodotto, la categoria del prodotto, il nome dello stato, il nome della regione di vendita
e un campo booleano valorizzato in base alla condizione che siano passati pi� di 180 giorni dalla data vendita o meno
(>180 -> True, <= 180 -> False)*/

SELECT 
	S.OrderID,
	S.OrderDate,
	SP.Product,
	SP.Category,
	SR.NameS,
	SR.NameR,
	CASE 
		WHEN DATEDIFF(day, S.OrderDate, GETDATE()) > 180 THEN 'True'
		ELSE 'False'
	END AS CheckDate
FROM Sales AS S
INNER JOIN VW_SM_StateRegion AS SR
ON S.StateID = SR.StateID
INNER JOIN VW_SM_SelfProduct AS SP
ON S.ProductID = SP.ProductID


/*Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/

SELECT
	YEAR(S.OrderDate) AS ANNO, 
	SUM (S.SalesAmount) AS TOT, 
	P.NameProduct 
FROM Sales AS S
INNER JOIN Product AS P 
ON S.ProductID = P.ProductID
GROUP BY 
	YEAR (OrderDate), P.NameProduct

/*esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/

SELECT 
	YEAR(S1.OrderDate) AS Anno, 
	S2.NameS AS Stato, 
	SUM(S1.SalesAmount) AS TOT
FROM Sales AS S1
INNER JOIN
[State] AS S2
ON S1.StateID = S2.StateID
GROUP BY 
	YEAR(S1.OrderDate), S2.NameS
ORDER BY 
	Anno DESC, TOT DESC

/*Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT TOP 1
	P.Category,
	SUM(S.SalesAmount) AS TOT
FROM VW_SM_SelfProduct AS P
INNER JOIN Sales AS S 
ON P.ProductID = S.ProductID
GROUP BY 
	P.Category
ORDER BY 
	TOT DESC


/*Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.
Ho sppeecificato le LEFT JOIN in modo da ottenere la riga aggiuntiva ovvero il prodotto non venduto*/

SELECT P.ProductID, 
	P.Product, S.OrderDate
FROM VW_SM_SelfProduct AS P
LEFT JOIN Sales AS S 
ON P.ProductID = S.ProductID
WHERE 
	S.OrderDate IS NULL;

SELECT P.ProductID, 
	P.Product, S.OrderDate
FROM VW_SM_SelfProduct AS P
LEFT JOIN Sales AS S 
ON P.ProductID = S.ProductID
WHERE 
	S.SalesAmount IS NULL;

/*Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).*/

SELECT
    P.ProductID,
    P.Product,
    MAX(S.OrderDate) AS LastDate
FROM VW_SM_SelfProduct AS P
INNER JOIN Sales AS S 
ON P.ProductID = S.ProductID
GROUP BY
    P.ProductID, P.Product 
ORDER BY 
	LastDate DESC

/*aggiunto la ORDER BY se si vuole avere anche come primo record l'ultima data di vendita delle ultime date di vendita dei 
singoli prodotti.*/